Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - C_Rogers ( https://freesound.org/people/C_Rogers/ )

You can find this pack online at: https://freesound.org/people/C_Rogers/packs/12990/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 203381__c-rogers__glass-shard-bounce-4.ogg
    * url: https://freesound.org/s/203381/
    * license: Creative Commons 0
  * 203380__c-rogers__glass-shard-bounce-3.ogg
    * url: https://freesound.org/s/203380/
    * license: Creative Commons 0
  * 203379__c-rogers__glass-shard-bounce.ogg
    * url: https://freesound.org/s/203379/
    * license: Creative Commons 0
  * 203378__c-rogers__glass-shard-bounce-2.ogg
    * url: https://freesound.org/s/203378/
    * license: Creative Commons 0
  * 203377__c-rogers__glass-shattering-05.ogg
    * url: https://freesound.org/s/203377/
    * license: Creative Commons 0
  * 203376__c-rogers__glass-broken-shifting.ogg
    * url: https://freesound.org/s/203376/
    * license: Creative Commons 0
  * 203375__c-rogers__glass-shattering-01.ogg
    * url: https://freesound.org/s/203375/
    * license: Creative Commons 0
  * 203374__c-rogers__glass-shattering-02.ogg
    * url: https://freesound.org/s/203374/
    * license: Creative Commons 0
  * 203373__c-rogers__glass-shattering-03.ogg
    * url: https://freesound.org/s/203373/
    * license: Creative Commons 0
  * 203372__c-rogers__glass-shattering-04.ogg
    * url: https://freesound.org/s/203372/
    * license: Creative Commons 0
  * 203371__c-rogers__glass-explosion-01.ogg
    * url: https://freesound.org/s/203371/
    * license: Creative Commons 0
  * 203370__c-rogers__glass-in-bucket-01.ogg
    * url: https://freesound.org/s/203370/
    * license: Creative Commons 0
  * 203369__c-rogers__glass-in-bucket-3thumps.ogg
    * url: https://freesound.org/s/203369/
    * license: Creative Commons 0
  * 203368__c-rogers__glass-shattering-hit-01.ogg
    * url: https://freesound.org/s/203368/
    * license: Creative Commons 0


